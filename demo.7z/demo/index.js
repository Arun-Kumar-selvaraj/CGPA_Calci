const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3001;
const dept="";
app.use(cors());

app.use(bodyParser.json());

app.post('/data', (req, res) => {
    if(res.ok){
    const receivedData = req.body;
    console.log('Received data:', receivedData);
    
    // Process the received data, e.g., save it to a database
    dept=res.json(receivedData);
    console.log('Received data:', dept
    );
    res.status(200).send('Data received successfully');}
    else{
        console.log("Not Received"); 
    }
  });

app.post('/data', (req, res) => {
  const receivedData = req.body;
  console.log('Received data:', receivedData);

  // Process the received data, e.g., save it to a database

  res.status(200).send('Data received successfully');
});

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'college',
});

connection.connect((err) => {
  if (err) {
   
    console.error('Error connecting to MySQL: ', err);
  } else {
    console.log('Connected to MySQL');
  }
});

app.get('/data', (req, res) => {
    const sem=4;
  const query = "SELECT * from cse where sem"+"="+sem;
  connection.query(query, (error, results) => {
    if (error) {
      console.error('Error executing query: ', error);
      res.status(500).json({ error: 'Internal Server Error' });
    } else {
      res.json(results);
      console.log(res);
    }
  });
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
